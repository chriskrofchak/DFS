mkdir -p /tmp/$USER/server

./watdfs_server /tmp/$USER/server
