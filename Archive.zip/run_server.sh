rm -rf /tmp/$USER/server
mkdir -p /tmp/$USER/server

./watdfs_server /tmp/$USER/server
